let rules = {
    sysModule: {
        modulename: { required: true, message: '请输入模块名称', trigger: 'blur' },
        moduleurl: { required: true, message: '请输入模块URL', trigger: 'blur' },
        redirect: { required: true, message: '请输入重定向路径', trigger: 'blur' },
        componet: { required: true, message: '请输入组件路径', trigger: 'blur' },
        moduleparentid: { required: true, message: '请选择上级模块', trigger: 'change' },
        modulestatus: { required: true, message: '请选择模块状态', trigger: 'change' },
        moduleordernum: { required: true, message: '请输入模块序号', trigger: 'blur' },
        activemenu: { required: true, message: '请输入activemenu', trigger: 'blur' },
        props: { required: true, message: '请输入模块序号', trigger: 'blur' },
        moduledescription: { required: true, message: '请输入模块描述', trigger: 'blur' },
        name: { required: true, message: '请输入路由名称', trigger: 'blur' },
        hidden: { required: true, message: '请选择模块是否显示', trigger: 'change' }
    }
}

export default rules