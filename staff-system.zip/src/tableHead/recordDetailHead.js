let Head={
	"!margins": {
		"left": 0.7875,
		"right": 0.7875,
		"top": 1.0527777777777778,
		"bottom": 1.0527777777777778,
		"header": 0.7875,
		"footer": 0.7875,
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"!cols":[{wpx:35},{wpx:75},{wpx:75},{wpx:45},{wpx:45},{wpx:45},{wpx:45},{wpx:45},{wpx:45},{wpx:45},{wpx:45},{wpx:45},{wpx:45},{wpx:45},{wpx:45},{wpx:137},{wpx:75}],
	"!rows":[{hpt:70,hpx:70},{hpt:42,hpx:42},{hpt:50,hpx:50},{hpt:100,hpx:100}],
	"A1": {
		"v": "华能大厦食堂——就餐消费结算表",
		"t": "s",
		"w": "华能大厦食堂——就餐消费结算表",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true,
				"sz":18
			}
		}
	},
	"A2": {
		"v": " 用餐单位（盖章）：XX公司 结算周期： 单位：元 ",
		"t": "s",
		"w": " 用餐单位（盖章）：XX公司 结算周期： 单位：元 ",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"A3": {
		"v": "序号",
		"t": "s",
		"w": "序号",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"B3": {
		"v": "公司名称（可筛选）",
		"t": "s",
		"w": "公司名称（可筛选）",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"C3": {
		"v": "部门（可筛选）",
		"t": "s",
		"w": "部门（可筛选）",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"D3": {
		"v": "用餐次数及金额",
		"t": "s",
		"w": "用餐次数及金额",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"P3": {
		"v": "应结算金额\n（元/月）\n",
		"t": "s",
		"w": "应结算金额\n（元/月）\n",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"Q3": {
		"v": "实际结算金额\n（元/月）\n",
		"t": "s",
		"w": "实际结算金额\n（元/月）\n",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"R3": {
		"v": "备注",
		"t": "s",
		"w": "备注",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"D4": {
		"v": "早餐次数\n",
		"t": "s",
		"w": "早餐次数\n",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"E4": {
		"v": "对应金额",
		"t": "s",
		"w": "对应金额",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"F4": {
		"v": "消费金额",
		"t": "s",
		"w": "消费金额",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"G4": {
		"v": "午餐次数",
		"t": "s",
		"w": "午餐次数",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"H4": {
		"v": "对应金额",
		"t": "s",
		"w": "对应金额",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"I4": {
		"v": "消费金额",
		"t": "s",
		"w": "消费金额",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"J4": {
		"v": "晚餐次数",
		"t": "s",
		"w": "晚餐次数",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"K4": {
		"v": "对应金额",
		"t": "s",
		"w": "对应金额",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"L4": {
		"v": "消费金额",
		"t": "s",
		"w": "消费金额",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"M4": {
		"v": "夜宵次数",
		"t": "s",
		"w": "夜宵次数",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"N4": {
		"v": "对应金额",
		"t": "s",
		"w": "对应金额",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"O4": {
		"v": "消费金额",
		"t": "s",
		"w": "消费金额",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"!ref": "A1:R4",
	"!merges": [{
		"s": {
			"c": 0,
			"r": 0
		},
		"e": {
			"c": 17,
			"r": 0
		}
	}, {
		"s": {
			"c": 0,
			"r": 1
		},
		"e": {
			"c": 17,
			"r": 1
		}
	}, {
		"s": {
			"c": 0,
			"r": 2
		},
		"e": {
			"c": 0,
			"r": 3
		}
	}, {
		"s": {
			"c": 1,
			"r": 2
		},
		"e": {
			"c": 1,
			"r": 3
		}
	}, {
		"s": {
			"c": 2,
			"r": 2
		},
		"e": {
			"c": 2,
			"r": 3
		}
	}, {
		"s": {
			"c": 3,
			"r": 2
		},
		"e": {
			"c": 14,
			"r": 2
		}
	}, {
		"s": {
			"c": 15,
			"r": 2
		},
		"e": {
			"c": 15,
			"r": 3
		}
	}, {
		"s": {
			"c": 16,
			"r": 2
		},
		"e": {
			"c": 16,
			"r": 3
		}
	}, {
		"s": {
			"c": 17,
			"r": 2
		},
		"e": {
			"c": 17,
			"r": 3
		}
	}]
}
export default Head