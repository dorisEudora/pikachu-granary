<template>
  <el-pagination
    @current-change="pageChange"
    @size-change="sizeChange"
    :current-page="page"
    :page-sizes="[5, 10, 20]"
    :page-size="listRows"
    layout="sizes, prev, pager, next, jumper"
    :total="total">
  </el-pagination>
</template>

<script>
  export default {
    props:{
      page:{
        type: Number,
        default: 1,
      },
      listRows: {
        type: Number,
        default: 20,
      },
      total:{
        type: Number,
        default: 0,
      }
    },
    methods:{
      sizeChange(listRows){
        this.$emit('update:listRows', listRows)
        this.$emit('page-change')
        this.$emit('fetchAllData', listRows, page)//后来加的,不影响之前的组件
      },
      pageChange(page){
        this.$emit('update:page', page)
        this.$emit('page-change')
        this.$emit('fetchAllData', listRows, page)//后来加的,不影响之前的组件
      }
    },
    computed:{
      show(){
        return this.total > this.listRows
      }
    },
  }
</script>

<style scoped>
  .el-pagination{
    margin-top: 15px;
  }
</style>