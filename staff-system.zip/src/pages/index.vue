<template>
  <div>
    <el-alert
      title="欢迎使用职称评审管理系统"
      type="success"
      description="请在左侧选择您所需的功能。"
      show-icon>
    </el-alert>
    <!-- <el-container>
      <el-header></el-header>
      <el-main>
        <el-row>
          <el-col :xl="10" :lg="12" :md="14" :sm="16" :xs="20" :offset="8">
            <h1>欢迎使用职称评审管理系统</h1>
          </el-col>
        </el-row>
      </el-main>
      <el-footer></el-footer>
    </el-container> -->
  </div>
</template>

<script>
  export default {
    
  }
</script>

<style scoped>
h1{
  font-size: 50px;
}
</style>