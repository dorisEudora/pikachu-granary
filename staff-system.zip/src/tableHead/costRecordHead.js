let Head={
	"!margins": {
		"left": 0.7875,
		"right": 0.7875,
		"top": 1.0527777777777778,
		"bottom": 1.0527777777777778,
		"header": 0.7875,
		"footer": 0.7875,
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"!cols":[{wpx:70},{wpx:123},{wpx:123},{wpx:123},{wpx:123},{wpx:123},{wpx:123},{wpx:123}],
	"!rows":[{hpt:65,hpx:65},{hpt:42,hpx:42},{hpt:75,hpx:75}],
	"A1": {
		"v": "华能大厦食堂——就餐消费结算表",
		"t": "s",
		"w": "华能大厦食堂——就餐消费结算表",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
                "bold": true,
                "sz":18
			}
		}
	},
	"A2": {
		"v": " 用餐单位（盖章）：XX公司                                                                                                       结算周期： ",
		"t": "s",
		"w": " 用餐单位（盖章）：XX公司                                                                                                      结算周期： ",
		"s": {
			"alignment": {
				"vertical": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"A3": {
		"v": "序号",
		"t": "s",
		"w": "序号",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"B3": {
		"v": "公司名称（可筛选）",
		"t": "s",
		"w": "公司名称（可筛选）",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"C3": {
		"v": "部门（可筛选）",
		"t": "s",
		"w": "部门（可筛选）",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"D3": {
		"v": "用餐总人数\n（人）",
		"t": "s",
		"w": "用餐总人数\n（人）",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"E3": {
		"v": "结算单价\n（元/月）",
		"t": "s",
		"w": "结算单价\n（元/月）",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"F3": {
		"v": "应结算金额\n（元/月）",
		"t": "s",
		"w": "应结算金额\n（元/月）",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"G3": {
		"v": "实际结算金额\n（元/月）",
		"t": "s",
		"w": "实际结算金额\n（元/月）",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"H3": {
		"v": "备注",
		"t": "s",
		"w": "备注",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"!ref": "A1:H3",
	"!merges": [{
		"s": {
			"c": 0,
			"r": 0
		},
		"e": {
			"c": 7,
			"r": 0
		}
	}, {
		"s": {
			"c": 0,
			"r": 1
		},
		"e": {
			"c": 7,
			"r": 1
		}
	}],

};
export default Head;