import Vue from 'vue'
import Router from 'vue-router'
import Layout from '@/pages/layout'
//import {menuRouter} from './router'
import Login from '@/pages/login'
import HelloWorld from '@/components/HelloWorld'
Vue.use(Router)

export const menuRouter = [
  // {
  //   path: '/index',
  //   component: Layout,
  //   name: "首页",
  //   children: [
  //     {
  //       path: '',
  //       name: "欢迎",
  //       component: () => import('@/pages/index'),
  //     }
  //   ]
  // },
  // {
  //   path: '/sysControl',
  //   name: '系统控制',
  //   component: Layout,
  //   redirect: '/sysControl/userManage',
  //   children: [
  //     {
  //       path: 'userManage',
  //       name: '用户管理',
  //       component: () => import('@/pages/sysControl/userManage/index')
  //     },
  //     {
  //       path: 'roleManage',
  //       name: '角色管理',
  //       component: () => import('@/pages/sysControl/roleManage/index')
  //     },
  //     {
  //       path: 'moduleManage',
  //       name: '模块管理',
  //       component: () => import('@/pages/sysControl/moduleManagement/index')
  //     }
  //   ]
  // },
  
  {
    path: '/',
    component: HelloWorld,
    redirect: '/login'
  },
  {
    path: '/login',
    component: Login
  }
]
export const router = new Router({
  routes: menuRouter
});

export const createRouter = () => new Router({
  base: process.env.BASE_URL,
  routes: menuRouter
});



