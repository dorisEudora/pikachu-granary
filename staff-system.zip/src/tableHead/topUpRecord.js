let Head={
	"!margins": {
		"left": 0.7875,
		"right": 0.7875,
		"top": 1.0527777777777778,
		"bottom": 1.0527777777777778,
		"header": 0.7875,
		"footer": 0.7875,
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"!cols":[{wpx:50},{wpx:50},{wpx:50},{wpx:50},{wpx:90},{wpx:90},{wpx:90},{wpx:90},{wpx:90},{wpx:90},{wpx:90},{wpx:90},{wpx:90},{wpx:90},{wpx:90},{wpx:50}],
	"!rows":[{hpt:105,hpx:105},{hpt:70,hpx:70},{hpt:100,hpx:100}],
	"A1": {
		"v": "华能大厦食堂——充值及消费情况汇总统计表",
		"t": "s",
		"w": "华能大厦食堂——充值及消费情况汇总统计表",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
                "bold": true,
                "sz":18
			}
		}
	},
	"A2": {
		"v": "序号",
		"t": "s",
		"w": "序号",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"B2": {
		"v": "公司名称\n（可筛选）",
		"t": "s",
		"w": "公司名称\n（可筛选）",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"C2": {
		"v": "部门\n（可筛选）",
		"t": "s",
		"w": "部门\n（可筛选）",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"D2": {
		"v": "姓名\n（可筛选）",
		"t": "s",
		"w": "姓名\n（可筛选）",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"E2": {
		"v": "上月结转情况",
		"t": "s",
		"w": "上月结转情况",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"G2": {
		"v": "当月充值情况",
		"t": "s",
		"w": "当月充值情况",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"I2": {
		"v": "扣减餐次情况",
		"t": "s",
		"w": "扣减餐次情况",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"N2": {
		"v": "本月结转下月情况",
		"t": "s",
		"w": "本月结转下月情况",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"P2": {
		"v": "备注",
		"t": "s",
		"w": "备注",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"E3": {
		"v": "上月结转次数",
		"t": "s",
		"w": "上月结转次数",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"F3": {
		"v": "结转金额",
		"t": "s",
		"w": "结转金额",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"G3": {
		"v": "充值次数",
		"t": "s",
		"w": "充值次数",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"H3": {
		"v": "补助金额",
		"t": "s",
		"w": "补助金额",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"I3": {
		"v": "早餐扣减次数",
		"t": "s",
		"w": "早餐扣减次数",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"J3": {
		"v": "午餐扣减次数",
		"t": "s",
		"w": "午餐扣减次数",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"K3": {
		"v": "晚餐扣减次数",
		"t": "s",
		"w": "晚餐扣减次数",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"L3": {
		"v": "夜宵扣减次数",
		"t": "s",
		"w": "夜宵扣减次数",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"M3": {
		"v": "合计扣减次数",
		"t": "s",
		"w": "合计扣减次数",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"N3": {
		"v": "结转次数",
		"t": "s",
		"w": "结转次数",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"O3": {
		"v": "结转金额",
		"t": "s",
		"w": "结转金额",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"!ref": "A1:P3",
	"!merges": [{
		"s": {
			"c": 0,
			"r": 0
		},
		"e": {
			"c": 15,
			"r": 0
		}
	}, {
		"s": {
			"c": 0,
			"r": 1
		},
		"e": {
			"c": 0,
			"r": 2
		}
	}, {
		"s": {
			"c": 1,
			"r": 1
		},
		"e": {
			"c": 1,
			"r": 2
		}
	}, {
		"s": {
			"c": 2,
			"r": 1
		},
		"e": {
			"c": 2,
			"r": 2
		}
	}, {
		"s": {
			"c": 3,
			"r": 1
		},
		"e": {
			"c": 3,
			"r": 2
		}
	}, {
		"s": {
			"c": 4,
			"r": 1
		},
		"e": {
			"c": 5,
			"r": 1
		}
	}, {
		"s": {
			"c": 6,
			"r": 1
		},
		"e": {
			"c": 7,
			"r": 1
		}
	}, {
		"s": {
			"c": 8,
			"r": 1
		},
		"e": {
			"c": 12,
			"r": 1
		}
	}, {
		"s": {
			"c": 13,
			"r": 1
		},
		"e": {
			"c": 14,
			"r": 1
		}
	}, {
		"s": {
			"c": 15,
			"r": 1
		},
		"e": {
			"c": 15,
			"r": 2
		}
	}],
}
export default Head