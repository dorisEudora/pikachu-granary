import store from '@/store/index.js'
/**
 *
 * @param {array} orginRoutes
 * @returns {array}
 * 将路由处理成能用的
 */
export function loopRoute(data) {

  let routes = []
  //console.log(data)
  data.forEach(val => {
    //console.log("router: ", val)
    let route = {}
    route.path = val.path
    if (val.props) {
      route.props = val.props
    }
    if (val.name) {
      route.name = val.name
    }
    if (val.component) {
      if (val.component === 'Layout') {
        //console.log("你好啊")
        route.component = () => import('@/pages/layout')
      } else {
        //console.log(`@/pages${val.component}`)
        route.component = () => import(`@/pages${val.component}`)
      }
    }

    //   if (val.hidden) {
    //     route.hidden = val.hidden
    //   }
    if (val.redirect && val.redirect != 'NULL') {
      route.redirect = val.redirect
    }
    route.meta = val.meta
    if (val.child && val.child.length !== 0) {
      route.children = loopRoute(val.child)
    }
    routes.push(route)
  })
  return routes
}

export function getSubRoutes() {//获取所有子路由，返回一个数组
  let result = []
  for (let item of store.getters.routes) {
    if (item.children)
      for (let subItem of item.children) {
        result.push(subItem.name)
      }
  }
  //console.log(result)
  return result
}
