// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import { router } from './router'
import Vuex from 'vuex'
import axios from 'axios'
import store from './store'
import ElementUI from 'element-ui'
import Api from '@/api/api'
import 'element-ui/lib/theme-chalk/index.css';
import 'font-awesome/css/font-awesome.min.css';
import md5 from 'js-md5'
import { getToken } from '@/utils/auth.js'
import './permission'// 权限控制
Vue.use(Vuex);

Vue.use(ElementUI);
Vue.prototype.$baseUrl = 'http://47.107.120.160:8081/'
//Vue.prototype.$baseUrl = 'http://59.110.161.163:8081/judge'
//Vue.prototype.$baseUrl = 'http://192.168.1.159:8081/judge'
// Vue.prototype.$baseUrl = 'http://10.253.6.138:8060/bcmsystem'
// Vue.prototype.$baseUrl = 'http://192.168.199.151:8010/bcmsystem'
// Vue.prototype.$baseUrl = 'http://120.79.46.144:8010/bcmsystem'
Vue.config.productionTip = false


Vue.prototype.$api = Api;
Vue.prototype.$md5 = md5;
Vue.prototype.$http = axios.create({
  baseURL: Vue.prototype.$baseUrl,
  withCredentials: false
})
Vue.prototype.$http.interceptors.request.use(function (config) {
  // 这里的config包含每次请求的内容
  let token = getToken()
  // 添加headers
  config.headers.token = `${token}`;
  config.headers['content-type'] = 'application/json;charset=UTF-8';
  return config;
}, function (err) {
  return Promise.reject(err);
})
Vue.prototype.$openMsg = (res) => {
  //显示消息
  Vue.prototype.$message({
    type: res.code == 200 ? "success" : "error",
    message: res.data.msg || res.msg
  })
}

Vue.prototype.vm = new Vue({
  el: '#app',
  router,
  store,
  components: { App },
  template: '<App/>'
})


