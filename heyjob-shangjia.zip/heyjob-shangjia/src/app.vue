
<script>
export default {
//全局js
}
</script>

<style lang="stylus" rel="stylesheet/stylus">
    page
        width 100%
        height 100% 
</style>