export function timestampFormat (timeStamp) { 
    let time = new Date(timeStamp)
    return time.getFullYear()+'/'+time.getMonth()+'/'+time.getDate()+' '+time.getHours()+':'+time.getMinutes()
 }