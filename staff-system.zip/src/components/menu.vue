<template>
  <div id="menu">
    <el-menu
      class="el-menu-vertical-demo"
      background-color="#495060"
      text-color="#c9cbd0"
      active-text-color="#2d8cf0"
      :collapse="menuCollapse"
      unique-opened
      :default-active="menuIndex"
      @select="menuSelect"
    >
      <el-menu-item class="logo" index="0" @click="$router.push('/index')">
        <img :src="logo" alt="logo" />
      </el-menu-item>
      <template
        v-for="(m,i) in menu.filter(menu => {
          return menu.hidden !== true;
        })"
      >
        <el-submenu :index="i.toString()" :key="i">
          <template slot="title">
            <i :class="m.icon"></i>
            <span slot="title">{{m.name}}</span>
          </template>
          <el-menu-item
            v-for="(sm,ii) in m.children"
            :data-index="i+'-'+ii"
            :index="i+'-'+ii"
            :key="ii"
          >{{sm.name}}</el-menu-item>
        </el-submenu>
      </template>
    </el-menu>
  </div>
</template>

<script>
import { mapGetters, mapMutations, mapActions } from "vuex";
import { menuRouter } from "@/router/index";

export default {
  data() {
    return {
      logo: require("../assets/logo.png"),
      menu: this.$store.getters.routes
      // menu: menuRouter
    };
  },

  computed: {
    ...mapGetters("layout", {
      menuCollapse: "menuCollapse",
      menuIndex: "menuIndex"
    })
  },
  watch: {
    menuCollapse(collapse) {
      this.logo = collapse
        ? require("../assets/logo.png")
        : require("../assets/logo.png");
    }
  },
  mounted() {
    // this.$api.get('/module',[this.$store.state.user.userName]).then(res=>{
    //   console.log(res.moduleTree)
    //   this.menu=res.moduleTree;
    // })
  },
  methods: {
    menuSelect(index, indexPath) {
      if (index != 0) {
        let menuIndex1 = indexPath[0];
        let menuIndex2 = 0;
        if (indexPath.length == 2) {
          let tmp = indexPath[1].split("-");
          menuIndex2 = tmp[1];
        }
        let path = "";
        let moduleId = "";
        this.menu.map((menu, i) => {
          if (i == menuIndex1) {
            path += menu.path;
            if (menu.children.length == 1) {
              path += "/" + menu.children[0].path;
              return false;
            } else {
              menu.children.map((children, i) => {
                if (i == menuIndex2) {
                  path += "/" + children.path;
                  moduleId = children.moduleId;
                  return false;
                }
              });
            }
          }
        });
        this.$store.commit("layout/setModuleId", moduleId);
        this.$store.commit(
          "layout/setMenuIndex",
          indexPath[indexPath.length - 1]
        );
        this.$router.replace(path);
      }
    }
  }
};
</script>

<style scoped lang="stylus">
#menu {
  display: flex;
  flex-direction: column;
  height: 100%;
  background-color: #495060;

  .logo {
    text-align: center;
    height: auto;
    padding: 12px 20px;

    img {
      height: 50px;
      width: auto;
      margin: 0 -14px;
    }
  }

  .el-menu {
    height: 100%;
    border-right: none;

    &:not(.el-menu--collapse) {
      width: 200px;
      min-height: 400px;
    }

    i {
      font-size: 24px;
      margin-right: 10px;
    }
  }
}
</style>