// 权限
import Vue from 'vue'
import store from './store'
import NProgress from 'nprogress' // Progress 进度条
import 'nprogress/nprogress.css' // Progress 进度条样式
import { router, menuRouter, createRouter } from '@/router'

router.beforeEach((to, from, next) => {
    NProgress.start()
    if (to.fullPath != '/login') {
        // 计算导航菜单indexPath（最多只算2级）
        //console.log(Vue.prototype.vm.$route)

        // let indexPath = ''
        // menuRouter.map((menu, i)=>{
        //   if(menu.path == to.matched[0].path){//to.matched[0] 父路由对象
        //     indexPath += i
        //     if(to.matched.length >= 2 && menu.children.length > 1){
        //       let childrenPath = to.matched[1].path.split('/').pop()
        //       menu.children.map((menu, i)=>{
        //         if(menu.path == childrenPath){
        //           indexPath += '-' + i
        //           return false
        //         }
        //       })
        //     }
        //     return false
        //   }
        // })
        //Vue.prototype.vm.$store.commit('layout/setMenuIndex', indexPath)
        store.commit('layout/addTab', to)
    } else {
        sessionStorage.clear()
    }

    if (!sessionStorage.getItem('user') && to.fullPath != '/login') {
        NProgress.done()
        next('/login');
    }
    else {
        //console.log("??",store.getters.routes)
        if ((sessionStorage.getItem('token') && store.getters.routes.length === 0)
            || from.fullPath === '/login') {
            store.dispatch('GetInfo').then(routes => {
                // console.log(routes)
                router.match = createRouter().match;
                router.addRoutes(routes);
                next()
            })
            NProgress.done()
            next();
        }
        NProgress.done()
        next()

    }
})