let Head={
	"A1": {
		"t": "s",
		"v": "华能大厦食堂——个人就餐消费明细表",
		"w": "华能大厦食堂——个人就餐消费明细表",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true,
				"sz":18
			}
		}
	},
	"!cols":[{wpx:26},{wpx:40},{wpx:55},{wpx:55},{wpx:55},{wpx:55},{wpx:55},{wpx:55},{wpx:55},{wpx:55},{wpx:55},{wpx:55},{wpx:55},{wpx:55},{wpx:55},{wpx:55},{wpx:55},{wpx:55},{wpx:55},{wpx:55},{wpx:85},{wpx:85}],
	"!rows":[{hpt:90,hpx:90},{hpt:42,hpx:42},{hpt:50,hpx:50},{hpt:80,hpx:80}],
	"A2": {
		"t": "s",
		"v": "用餐单位（盖章）：XX公司 结算周期： ",
		"w": "用餐单位（盖章）：XX公司 结算周期： ",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"A3": {
		"t": "s",
		"v": "序号",
		"w": "序号",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"B3": {
		"t": "s",
		"v": "公司名称\n（可筛选）",
		"w": "公司名称\n（可筛选）",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"C3": {
		"t": "s",
		"v": "部门\n（可筛选）",
		"w": "部门\n（可筛选）",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"D3": {
		"t": "s",
		"v": "姓名\n（可筛选）",
		"w": "姓名\n（可筛选）",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"E3": {
		"t": "s",
		"v": "用餐次数及金额（次数）",
		"w": "用餐次数及金额（次数）",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"M3": {
		"t": "s",
		"v": "其他用餐形式次数及金额（电子钱包或微信）",
		"w": "其他用餐形式次数及金额（电子钱包或微信）",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"U3": {
		"t": "s",
		"v": "消费次数合计\n（次）",
		"w": "消费次数合计\n（次）",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"V3": {
		"t": "s",
		"v": "消费金额合计\n（元/月）",
		"w": "消费金额合计\n（元/月）",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"E4": {
		"t": "s",
		"v": "早餐\n次数",
		"w": "早餐\n次数",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"F4": {
		"t": "s",
		"v": "金额\n（元）",
		"w": "金额\n（元）",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"G4": {
		"t": "s",
		"v": "午餐\n次数",
		"w": "午餐\n次数",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"H4": {
		"t": "s",
		"v": "金额\n（元）",
		"w": "金额\n（元）",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"I4": {
		"t": "s",
		"v": "晚餐\n次数",
		"w": "晚餐\n次数",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"J4": {
		"t": "s",
		"v": "金额\n（元）",
		"w": "金额\n（元）",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"K4": {
		"t": "s",
		"v": "夜宵\n次数",
		"w": "夜宵\n次数",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"L4": {
		"t": "s",
		"v": "金额\n（元）",
		"w": "金额\n（元）",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"M4": {
		"t": "s",
		"v": "早餐",
		"w": "早餐",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"N4": {
		"t": "s",
		"v": "金额\n（元）",
		"w": "金额\n（元）",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"O4": {
		"t": "s",
		"v": "午餐",
		"w": "午餐",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"P4": {
		"t": "s",
		"v": "金额\n（元）",
		"w": "金额\n（元）",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"Q4": {
		"t": "s",
		"v": "晚餐",
		"w": "晚餐",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"R4": {
		"t": "s",
		"v": "金额\n（元）",
		"w": "金额\n（元）",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"S4": {
		"t": "s",
		"v": "夜宵",
		"w": "夜宵",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"T4": {
		"t": "s",
		"v": "金额\n（元）",
		"w": "金额\n（元）",
		"s": {
			"alignment": {
				"vertical": "center",
				"horizontal": "center",
				"wrapText": true
			},
			"font": {
				"bold": true
			}
		}
	},
	"!ref": "A1:V4",
	"!merges": [{
		"s": {
			"r": 0,
			"c": 0
		},
		"e": {
			"r": 0,
			"c": 21
		}
	}, {
		"s": {
			"r": 1,
			"c": 0
		},
		"e": {
			"r": 1,
			"c": 21
		}
	}, {
		"s": {
			"r": 2,
			"c": 0
		},
		"e": {
			"r": 3,
			"c": 0
		}
	}, {
		"s": {
			"r": 2,
			"c": 1
		},
		"e": {
			"r": 3,
			"c": 1
		}
	}, {
		"s": {
			"r": 2,
			"c": 2
		},
		"e": {
			"r": 3,
			"c": 2
		}
	}, {
		"s": {
			"r": 2,
			"c": 3
		},
		"e": {
			"r": 3,
			"c": 3
		}
	}, {
		"s": {
			"r": 2,
			"c": 4
		},
		"e": {
			"r": 2,
			"c": 11
		}
	}, {
		"s": {
			"r": 2,
			"c": 12
		},
		"e": {
			"r": 2,
			"c": 19
		}
	}, {
		"s": {
			"r": 2,
			"c": 20
		},
		"e": {
			"r": 3,
			"c": 20
		}
	}, {
		"s": {
			"r": 2,
			"c": 21
		},
		"e": {
			"r": 3,
			"c": 21
		}
	}]
}
export default Head