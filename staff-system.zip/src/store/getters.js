export default {
    token: state => state.token,
    routes: state => state.routes
}